﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;

namespace lejatszo2
{
    public partial class MainWindow : Window
    {
        private MediaPlayer mediaPlayer = new MediaPlayer();
        private DispatcherTimer timer = new DispatcherTimer();
        private ObservableCollection<string> playlist = new ObservableCollection<string>();
        private ObservableCollection<string> loadedMusic = new ObservableCollection<string>();
        private int currentIndex = -1;

        public MainWindow()
        {
            InitializeComponent();
            Playlist.ItemsSource = playlist;
            LoadedMusicList.ItemsSource = loadedMusic;
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            VolumeSlider.Value = mediaPlayer.Volume * 100;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (mediaPlayer.Source != null)
            {
                if (mediaPlayer.NaturalDuration.HasTimeSpan)
                {
                    ProgressSlider.Value = mediaPlayer.Position.TotalSeconds;
                    TimeInfo.Text = $"{mediaPlayer.Position:mm\\:ss} / {mediaPlayer.NaturalDuration.TimeSpan:mm\\:ss}";
                }
                else
                {
                    ProgressSlider.Value = 0;
                    TimeInfo.Text = $"{mediaPlayer.Position:mm\\:ss} / ---";
                }
            }
        }

        private void BtnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (mediaPlayer.Source != null)
            {
                mediaPlayer.Play();
                timer.Start();
            }
            else if (playlist.Count > 0)
            {
                currentIndex = 0;
                PlayCurrentSong();
            }
        }

        private void BtnPause_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Pause();
            timer.Stop();
        }

        private void BtnStop_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Stop();
            timer.Stop();
            mediaPlayer.Position = TimeSpan.Zero; 
            ProgressSlider.Value = 0; 
            TimeInfo.Text = "00:00 / ---"; 
        }

        private void BtnPrevious_Click(object sender, RoutedEventArgs e)
        {
            if (loadedMusic.Count > 0)
            {
                currentIndex--;
                if (currentIndex < 0)
                {
                    currentIndex = loadedMusic.Count - 1;
                }
                LoadedMusicList.SelectedIndex = currentIndex;
            }
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            if (loadedMusic.Count > 0)
            {
                currentIndex++;
                if (currentIndex >= loadedMusic.Count)
                {
                    currentIndex = 0;
                }
                LoadedMusicList.SelectedIndex = currentIndex;
            }
        }





        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Volume = VolumeSlider.Value / 100;
        }

        private void BtnAddToPlaylist_Click(object sender, RoutedEventArgs e)
        {
            if (LoadedMusicList.SelectedItem != null)
            {
                playlist.Add(LoadedMusicList.SelectedItem.ToString());
            }
        }

        private void BtnRemoveFromPlaylist_Click(object sender, RoutedEventArgs e)
        {
            if (Playlist.SelectedIndex >= 0)
            {
                playlist.RemoveAt(Playlist.SelectedIndex);
                if (currentIndex >= playlist.Count)
                {
                    currentIndex = playlist.Count - 1;
                }
                PlayCurrentSong();
            }
        }

        private void BtnSavePlaylist_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Playlist Files|*.playlist";
            if (saveFileDialog.ShowDialog() == true)
            {
                System.IO.File.WriteAllLines(saveFileDialog.FileName, playlist);
            }
        }

        private void BtnLoadPlaylist_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Playlist Files|*.playlist";
            if (openFileDialog.ShowDialog() == true)
            {
                playlist.Clear();
                foreach (string line in System.IO.File.ReadAllLines(openFileDialog.FileName))
                {
                    playlist.Add(line);
                }
                currentIndex = 0;
                PlayCurrentSong();
            }
        }

        private void Playlist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Playlist.SelectedIndex >= 0)
            {
                currentIndex = Playlist.SelectedIndex;
                PlayCurrentSong();
            }
        }

        private void PlayCurrentSong()
        {
            if (currentIndex >= 0 && currentIndex < playlist.Count)
            {
                mediaPlayer.Open(new Uri(playlist[currentIndex]));
                mediaPlayer.Play();
                timer.Start();
                MusicInfo.Text = System.IO.Path.GetFileName(playlist[currentIndex]);
            }
        }

        private void BtnLoadMusic_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "Audio Files|*.mp3;*.wav;*.wma";
            if (openFileDialog.ShowDialog() == true)
            {
                foreach (string filename in openFileDialog.FileNames)
                {
                    loadedMusic.Add(filename);
                }
            }
        }

        private void LoadedMusicList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LoadedMusicList.SelectedItem != null)
            {
                string selectedMusic = LoadedMusicList.SelectedItem.ToString();
                mediaPlayer.Open(new Uri(selectedMusic));
                MusicInfo.Text = System.IO.Path.GetFileName(selectedMusic);
                mediaPlayer.Play();
                timer.Start();
            }
        }
    }
}
