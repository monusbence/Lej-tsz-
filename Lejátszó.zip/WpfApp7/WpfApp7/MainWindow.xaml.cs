﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;

namespace WpfApp7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MediaPlayer mediaPlayer = new MediaPlayer();
        ObservableCollection<string> playlist = new ObservableCollection<string>();
        int currentSongIndex = -1;
        DispatcherTimer timer;
        private TimeSpan pausedPosition;
        public MainWindow()
        {
            InitializeComponent();
            mediaPlayer.MediaEnded += MediaPlayer_MediaEnded;
            mediaPlayer.MediaOpened += MediaPlayer_MediaOpened;
            volumeSlider.ValueChanged += VolumeSlider_ValueChanged;
            lstPlaylist.ItemsSource = playlist;

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateStatus();
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (playlist.Count == 0) return;
            if (currentSongIndex == -1) currentSongIndex = 0;

            if (mediaPlayer.Source != null && mediaPlayer.CanPause && mediaPlayer.Position != TimeSpan.Zero)
            {
                mediaPlayer.Play();
                mediaPlayer.Position = pausedPosition;
            }
            else
            {
                mediaPlayer.Open(new Uri(playlist[currentSongIndex]));
                mediaPlayer.Play();
            }
        }

        private void btnPause_Click(object sender, RoutedEventArgs e)
        {
            if (mediaPlayer.Source != null && mediaPlayer.CanPause)
            {
                mediaPlayer.Pause();
                pausedPosition = mediaPlayer.Position;
                UpdateStatus();
            }
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Stop();
            UpdateStatus();
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            if (playlist.Count == 0) return;
            currentSongIndex = (currentSongIndex + 1) % playlist.Count;
            btnPlay_Click(sender, e);
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Filter = "MP3 files (*.mp3)|*.mp3|All files (*.*)|*.*";
            openFileDialog.Multiselect = true;
            if (openFileDialog.ShowDialog() == true)
            {
                foreach (string filename in openFileDialog.FileNames)
                {
                    playlist.Add(filename);
                }
            }
        }

        private void AddToPlaylist(string filePath)
        {
            if (!playlist.Contains(filePath))
            {
                playlist.Add(filePath);
            }
        }

        private void RemoveFromPlaylist(string filePath)
        {
            playlist.Remove(filePath);
        }

        private void PlayFromPlaylist()
        {
            if (playlist.Count > 0)
            {
                currentSongIndex = 0;
                btnPlay_Click(null, null);
            }
        }

        private void SavePlaylist(string filePath)
        {
            File.WriteAllLines(filePath, playlist);
        }

        private void LoadPlaylist(string filePath)
        {
            if (File.Exists(filePath))
            {
                playlist.Clear();
                foreach (string line in File.ReadAllLines(filePath))
                {
                    AddToPlaylist(line);
                }
            }
        }

        private void btnAddToPlaylist_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Filter = "MP3 files (*.mp3)|*.mp3|All files (*.*)|*.*";
            openFileDialog.Multiselect = true;
            if (openFileDialog.ShowDialog() == true)
            {
                foreach (string filename in openFileDialog.FileNames)
                {
                    AddToPlaylist(filename);
                }
            }
        }

        private void btnRemoveFromPlaylist_Click(object sender, RoutedEventArgs e)
        {
            if (lstPlaylist.SelectedItem != null)
            {
                RemoveFromPlaylist(lstPlaylist.SelectedItem.ToString());
            }
        }

        private void btnPlayFromPlaylist_Click(object sender, RoutedEventArgs e)
        {
            PlayFromPlaylist();
        }

        private void btnSavePlaylist_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == true)
            {
                SavePlaylist(saveFileDialog.FileName);
            }
        }

        private void btnLoadPlaylist_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                LoadPlaylist(openFileDialog.FileName);
            }
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (lstPlaylist.SelectedItem != null)
            {
                playlist.RemoveAt(lstPlaylist.SelectedIndex);
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            playlist.Clear();
            currentSongIndex = -1;
            mediaPlayer.Stop();
            UpdateStatus();
        }

        private void MediaPlayer_MediaEnded(object sender, EventArgs e)
        {
            btnNext.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MediaPlayer_MediaOpened(object sender, EventArgs e)
        {
            UpdateStatus();
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mediaPlayer.Volume = volumeSlider.Value;
        }

        private TimeSpan GetElapsedTime()
        {
            if (mediaPlayer.Position != TimeSpan.Zero && mediaPlayer.NaturalDuration.HasTimeSpan)
            {
                return mediaPlayer.Position;
            }
            else
            {
                return TimeSpan.Zero;
            }
        }

        private void UpdateStatus()
        {
            if (mediaPlayer.Source != null)
            {
                string currentSong = System.IO.Path.GetFileNameWithoutExtension(mediaPlayer.Source.LocalPath);
                string length = mediaPlayer.NaturalDuration.HasTimeSpan ? mediaPlayer.NaturalDuration.TimeSpan.ToString(@"mm\:ss") : "00:00";
                string elapsedTime = mediaPlayer.Position.ToString(@"mm\:ss");
                txtStatus.Text = $"{elapsedTime} / {length} - {currentSong}";
            }
            else
            {
                txtStatus.Text = "No song played";
            }
        }
    }
}
